<?php

    /* ==========================================================================
    ** Send New Anncio Confirmation Mail
    ** 24/01/2019
    ** Alan Medina Silva
    ** ========================================================================== */
    
    
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
	header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
	header('P3P: CP="CAO PSA OUR"'); // Makes IE to support cookies
	header("Content-Type: application/json; charset=utf-8");

    // get database connection
    // include_once '../config/database.php';    
    // instantiate user object
    // include_once '../objects/anuncios/Anuncios.php';
    include_once '../objects/emailer/Emailer.php';
    include_once '../objects/emailTemplate/EmailTemplate.php';

    $emails = array(
        'alanmedina43@gmail.com',
        'you@yoursite.com'
    );
    
    $Emailer = new Emailer($emails);
     //More code here
    
    $Template = new EmailTemplate('../emailTemplate/srseminuevos-email-confirmacion.php');
        // $Template->Firstname = 'Robert';
        // $Template->Lastname = 'Pitt';
        // $Template->LoginUrl= 'http://stackoverflow.com/questions/3706855/send-email-with-a-template-using-php';
        //...


    var_dump($Template);
    
    $Emailer->SetTemplate($Template); //Email runs the compile
    $Emailer->send();



?>